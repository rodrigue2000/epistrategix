// ===== SERVEUR PRINCIPAL =====
console.log('🚀 Démarrage du serveur...');

const express = require('express');
const cors = require('cors');
const app = express();
const port = process.env.PORT || 5000;

// ✅ Render (comme la plupart des hébergeurs) place l'app derrière un proxy
// inverse qui ajoute l'en-tête X-Forwarded-For. Sans ce réglage,
// express-rate-limit ne peut pas identifier fiablement l'IP réelle du client.
app.set('trust proxy', 1);

// Middleware CORS (toujours global, ne pose pas de problème)
app.use(cors());

// ✅ IMPORTANT : express.json() ne doit PAS s'appliquer à la route webhook,
// car le webhook FedaPay a besoin du corps brut (raw body) pour vérifier
// la signature HMAC. Si express.json() parse le body avant, le webhook
// reçoit un objet déjà parsé et la vérification de signature échoue
// systématiquement, même avec la bonne URL et le bon secret.
app.use((req, res, next) => {
    if (req.originalUrl.startsWith('/webhooks/fedapay')) {
        return next(); // on saute express.json() pour cette route
    }
    express.json()(req, res, next);
});

// === ROUTES DE BASE ===
app.get('/', (req, res) => {
    res.send('✅ EpiStrategix API - en ligne');
});

app.get('/health', (req, res) => {
    res.json({
        status: 'OK',
        timestamp: new Date().toISOString(),
        env: process.env.NODE_ENV || 'development'
    });
});

// === IMPORT DES CONFIGURATIONS ===
let firebaseReady = false;
try {
    // Forcer le chargement de firebase.js qui gère l'initialisation
    const { db } = require('./config/firebase');
    if (db) {
        firebaseReady = true;
        console.log('✅ Firebase connecté avec succès');
    }
} catch (err) {
    console.error('❌ Erreur Firebase:', err.message);
}

// === ROUTES API ===
if (firebaseReady) {
    try {
        console.log('📦 Chargement des routes...');

        const servicesRoutes = require('./routes/services');
        const reservationsRoutes = require('./routes/reservations');
        const paymentsRoutes = require('./routes/payments');
        const contentsRoutes = require('./routes/contents');
        const bundlesRoutes = require('./routes/bundles');
        const categoriesRoutes = require('./routes/categories');
        const purchasesRoutes = require('./routes/purchases');
        const trainingsRoutes = require('./routes/trainings');
        const adminRoutes = require('./routes/admin');
        const webhookRoutes = require('./webhooks/fedapay');

        app.use('/api/services', servicesRoutes);
        app.use('/api/reservations', reservationsRoutes);
        app.use('/api/payments', paymentsRoutes);
        app.use('/api/contents', contentsRoutes);
        app.use('/api/bundles', bundlesRoutes);
        app.use('/api/categories', categoriesRoutes);
        app.use('/api/purchases', purchasesRoutes);
        app.use('/api/trainings', trainingsRoutes);
        app.use('/api/admin', adminRoutes);

        // ✅ Chemin corrigé : "webhooks" au pluriel, pour correspondre
        // exactement à l'URL déclarée dans le dashboard FedaPay
        app.use('/webhooks/fedapay', webhookRoutes);

        console.log('✅ Routes API chargées avec succès');
    } catch (err) {
        console.error('❌ Erreur chargement routes:', err.message);
        console.error('Stack:', err.stack);

        // ✅ Sans ce fallback, une erreur de chargement de route renvoyait une
        // page HTML 404 par défaut d'Express au lieu de JSON, ce qui cassait
        // silencieusement tous les fetch() côté frontend avec une erreur de
        // parsing JSON peu explicite ("Unexpected token '<'").
        app.use('/api', (req, res) => {
            res.status(500).json({
                error: 'Erreur de chargement des routes API',
                hint: err.message
            });
        });
    }
} else {
    console.warn('⚠️ Firebase non disponible - routes API désactivées');
    app.get('/api/*', (req, res) => {
        res.status(503).json({
            error: 'Service non disponible',
            hint: 'Vérifiez vos variables Firebase sur Render'
        });
    });
    app.post('/api/*', (req, res) => {
        res.status(503).json({
            error: 'Service non disponible',
            hint: 'Vérifiez vos variables Firebase sur Render'
        });
    });
}

// === ROUTE DE STATUT ===
app.get('/api/status', (req, res) => {
    res.json({
        firebase: firebaseReady ? '✅ OK' : '❌ Désactivé',
        timestamp: new Date().toISOString(),
        env: process.env.NODE_ENV || 'development'
    });
});

// === GESTION DES ERREURS ===
process.on('uncaughtException', (err) => {
    console.error('❌ Uncaught Exception:', err.message);
});

process.on('unhandledRejection', (reason) => {
    console.error('❌ Unhandled Rejection:', reason);
});

// === DÉMARRAGE ===
app.listen(port, '0.0.0.0', () => {
    console.log(`✅ Serveur démarré sur le port ${port}`);
    console.log(`📊 Firebase: ${firebaseReady ? '✅ OK' : '❌ DÉSACTIVÉ'}`);
    console.log(`🔗 URL: https://epistrategix-backend.onrender.com`);
});
